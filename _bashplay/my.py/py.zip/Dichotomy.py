from random import random
if input("You choose?")=="no":
    num=round(random()*100)
    x=0
    while x!=num:
        x=int(input(""))
        if x<num:
            print("Higher!")
        elif x>num:
            print("Lower!")
    print("You win!")
else:
    num=int(input("Number: "))
    low=0
    hi=100
    guess=50
    print(50)
    while guess!=num:
        if guess<num:
            low=guess
            guess=round((low+hi)/2)
        elif guess>num:
            hi=guess
            guess=round((low+hi)/2)
        print(guess)
