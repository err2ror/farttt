z=open("catme","x")
z=open("catme","a")

x=1
y=1000000
while x <= y:
     print(f"{x} [{(x/y)*100}%]")
     x+=1
     z.write(f"""{x} [{(x/y)*100}%]
     """)
