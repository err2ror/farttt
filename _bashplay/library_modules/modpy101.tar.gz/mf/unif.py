def uhex(he):
    return chr(int(f"0x{he}",16))
