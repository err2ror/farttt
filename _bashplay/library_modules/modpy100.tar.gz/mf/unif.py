def uhex(he):
    return chr(hex(f"0x{he}",16))
