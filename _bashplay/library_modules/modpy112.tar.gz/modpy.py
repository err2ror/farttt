from mf.pytropy import *
from mf.unif import *
from mf.rmt import *
from mf.bbash import *
from mf.thing import *
if __name__=="__main__":
    print("ModPy 1.1.2")
